package com.cg.jpaexam.author;

import java.util.List;
import java.util.Scanner;

import com.cg.jpaexam.entities.Author;
import com.cg.jpaexam.exception.AuthorException;
import com.cg.jpaexam.service.AuthorService;
import com.cg.jpaexam.service.IAuthorService;


public class AuthorMain {

	public static void main(String[] args) {
		
		int choice=0;
		int id=0;
		String fname=null;
		String mname=null;
		String lname=null;
		String pnumber=null;
		Scanner scInput=new Scanner(System.in);
        IAuthorService service = new AuthorService();
		
		
		while(true){
		System.out.println("You can perform following operations:");
		System.out.println("1.Add the author details");
		System.out.println("2.Delete author details");
		System.out.println("3.Find the author details");
		System.out.println("4.View all author details");
		System.out.println("5.Update author details");
		System.out.println("Enter your choice");
		choice=scInput.nextInt();
		scInput.nextLine();
		switch(choice){
		case 1: 
			System.out.println("Enter first name");
			fname=scInput.nextLine();
			System.out.println("Enter the middle name");
			mname=scInput.nextLine();
			System.out.println("Enter last name");
			lname=scInput.nextLine();
			System.out.println("Enter the phone number");
			pnumber=scInput.nextLine();
			Author author = new Author();
			author.setFirstName(fname);
			author.setMiddleName(mname);
			author.setLastName(lname);
			author.setPhoneNo(pnumber);
			
			
			try {
				int id1 = service.addAuthor(author);
				System.out.println("Author added successfully\nAuthor ID is : " + id1);
			    }catch (AuthorException e) {
				System.out.println("Author couldn't be added"+e.getMessage());
			    }
			break;
		case 2:
			System.out.println("Enter the author id to be deleted");
			id=scInput.nextInt();
			scInput.nextLine();
			
			try {
				author=service.deleteAuthor(id);
				if(author!=null){
					System.out.println("Author deleted successfully\nThe details are\n");
					System.out.println(author.getFirstName()+" "+author.getMiddleName()+" "+author.getLastName()+" "+author.getPhoneNo());
				}
				else{
					System.out.println("Author not found");
				}
			    }catch(AuthorException e){
				System.out.println("Author couldn't be deleted"+e.getMessage());
			    }
			break;
		case 3:
			System.out.println("Enter the author id to be found");
			id=scInput.nextInt();
			scInput.nextLine();
			
			try {
				author=service.findAuthor(id);
				if(author!=null){
					System.out.println("Author information found and is as follows:\n");
					System.out.println(author.getFirstName()+" "+author.getMiddleName()+" "+author.getLastName()+" "+author.getPhoneNo());
				}
				else{
					System.out.println("Author not found!!!");
				}
			    }catch (AuthorException e) {
				System.out.println("No records found"+e.getMessage());
			    }
			break;
		case 4:
			
			try {
				List<Author> list=service.viewAllAuthor();
				for(Author authList : list){
					System.out.println(authList);
				}
			    }catch (AuthorException e) {
				System.out.println("Record not found"+e.getMessage());
			    }
			break;
		case 5:
			System.out.println("Enter the author id to be updated");
			id=scInput.nextInt();
			scInput.nextLine();
			System.out.println("Enter the new phone number");
			pnumber=scInput.nextLine();
			
			try {
				author=service.updateAuthor(id, pnumber);
				if(author!=null){
					System.out.println("Author information updated successfully:\n");
					System.out.println(author.getFirstName()+" "+author.getMiddleName()+" "+author.getLastName()+" "+author.getPhoneNo());
				}
				else{
					System.out.println("Id not found");
				}
			} catch (AuthorException e) {
				System.out.println("Record not found"+e.getMessage());
			}
			
			
			
		}
		}
	}

}
