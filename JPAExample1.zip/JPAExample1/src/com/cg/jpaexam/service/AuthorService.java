package com.cg.jpaexam.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.jpaexam.dao.AuthorDaoImpl;
import com.cg.jpaexam.dao.IAuthorDao;
import com.cg.jpaexam.entities.Author;
import com.cg.jpaexam.exception.AuthorException;

public class AuthorService implements IAuthorService {
	
	private EntityManager em;
	private EntityManagerFactory emf;
	
	private IAuthorDao dao;
	public AuthorService() {
		dao=new AuthorDaoImpl();
	}

	@Override
	public int addAuthor(Author author) throws AuthorException {
	dao.beginTransaction();
	int id=dao.addAuthor(author);
	dao.commitTransaction();
	return id;	
	}

	@Override
	public Author deleteAuthor(int authorId) throws AuthorException {
		dao.beginTransaction();
		Author atr=dao.deleteAuthor(authorId);
		dao.commitTransaction();
		
		return atr;
	}

	@Override
	public Author findAuthor(int authorId) throws AuthorException {
		dao.beginTransaction();
		Author atr=dao.findAuthor(authorId);
		dao.commitTransaction();
		
		return atr;
	}

	@Override
	public List<Author> viewAllAuthor() throws AuthorException {
		dao.beginTransaction();
		List<Author> list=dao.viewAllAuthor();
		dao.commitTransaction();
		return list;
	}

	@Override
	public Author updateAuthor(int authorId, String phoneNo)
			throws AuthorException {
		dao.beginTransaction();
		Author author=dao.updateAuthor(authorId, phoneNo);
		dao.commitTransaction();
		return author;
	}

}
