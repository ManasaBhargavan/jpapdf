package com.cg.jpaexam.service;

import java.util.List;

import com.cg.jpaexam.entities.Author;
import com.cg.jpaexam.exception.AuthorException;

public interface IAuthorService {

	public int addAuthor(Author author)throws AuthorException;
	
    public Author deleteAuthor(int authorId)throws AuthorException;
	
	public Author findAuthor(int authorId)throws AuthorException;
	
	public List<Author> viewAllAuthor() throws AuthorException;
	
	public Author updateAuthor(int authorId,String phoneNo)throws AuthorException;
}
