package com.cg.jpaexam.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;



import com.cg.jpaexam.entities.Author;
import com.cg.jpaexam.exception.AuthorException;

public class AuthorDaoImpl implements IAuthorDao {
	
	private EntityManager em;
	

	
	
	public AuthorDaoImpl() {
		em = JPAUtil.getEntityManager();
	}

	@Override
	public int addAuthor(Author author) throws AuthorException {
		em.persist(author);
		int id=author.getAuthorId();
		return id;
	}

	@Override
	public Author deleteAuthor(int authorId) throws AuthorException {
		Author atr=em.find(Author.class,authorId);
		if(atr!=null){
			em.remove(atr);
		}
		return atr;
	}

	@Override
	public Author findAuthor(int authorId) throws AuthorException {
		Author atr=em.find(Author.class, authorId);
		if(atr==null)
		{
			System.out.println("Author not found");
		}
		else
		{
			System.out.println("Author found!!!");
		}
		return atr;
	}

	@Override
	public List<Author> viewAllAuthor() throws AuthorException {
TypedQuery<Author> qry = em.createQuery("from Author",Author.class);
		
		List<Author> list = qry.getResultList();
		
		return list;
	}

	@Override
	public void commitTransaction() {
		em.getTransaction().commit();
		
	}

	@Override
	public void beginTransaction() {
		em.getTransaction().begin();
		
	}

	@Override
	public Author updateAuthor(int authorId, String phoneNo)
			throws AuthorException {
		
Author author = em.find(Author.class, authorId);
		
		if(author!=null){
			
			author.setPhoneNo(phoneNo);
			
			em.merge(author);
		}
		return author;
	}

}
