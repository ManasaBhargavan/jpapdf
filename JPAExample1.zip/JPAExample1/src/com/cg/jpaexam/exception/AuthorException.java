package com.cg.jpaexam.exception;

public class AuthorException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -338498049649702787L;

	public AuthorException() {
		super();
	}

	public AuthorException(String message) {
		super(message);
	}

}
